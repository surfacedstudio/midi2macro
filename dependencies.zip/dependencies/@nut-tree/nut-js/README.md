# nut.js (Native UI Toolkit)

This is the core package for nut.js, the one package that keeps all the other packages together. It provides the basic functionality to interact with the screen, the keyboard, and the mouse.