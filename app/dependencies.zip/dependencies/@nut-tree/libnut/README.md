# @nut-tree/libnut
Installation meta package for platform dependent libnut packages

## Installation
```bash
npm i @nut-tree/libnut
```

or

```bash
yarn add @nut-tree/libnut
```
